# Reproducing the compatible-memory pilot

This package retains 50 independently trained checkpoints, a new French text
corpus with provenance, a protocol frozen before full training, exact rational
stability/error evidence, compression replay and independent audit.

Use a copy to retain the original evidence. Python 3.12 and CPU PyTorch were
used; exact versions and source hashes are in results/run_manifest.json.

```bash
python -m pip install torch numpy matplotlib
python code/audit_checks.py --require-complete
python code/certify.py --self-test
python code/certify.py
python code/verify_certificate.py --require-complete
python code/replay_compression.py
python code/analyse.py
```

To rerun training in a separate copy, first move the supplied results and
checkpoints elsewhere, recreate those two directories, and run:

```bash
python code/run_all.py
python code/audit_checks.py --require-complete
python code/certify.py
python code/verify_certificate.py --require-complete
python code/replay_compression.py
python code/analyse.py
```

The launcher refuses to overwrite existing run JSON evidence. It runs three
single-thread CPU jobs at once. Timings measured during concurrency are
indicative, not controlled throughput benchmarks. Data can be reconstructed
from the supplied raw Gutenberg file using code/prepare_data.py; inspect its
documented inputs first. No network or prior checkpoints are needed to train.

All full models have 64 FP32 persistent recurrent coordinates, 256 bytes per
sample. Parameters, temporary buffers and training activations are separate.
The projection reduces only the four residual heads from 8 to 4 coordinates,
giving 192 bytes per sample. It is fixed in the original coordinate basis and
is not fitted or chosen using validation or test results.

The certificate covers the exact real-arithmetic interpretation of the frozen
effective dyadic coefficients exported with every selected checkpoint. It
requires shared inputs/routes/injections, zero initial states, and scalar
linear residual outputs added to logits. No certificate for floating-point
accumulation errors, free-running generated tokens, or optimal AAK synthesis
is claimed. See MATH.md, PROTOCOL.md and certificates/*.json.

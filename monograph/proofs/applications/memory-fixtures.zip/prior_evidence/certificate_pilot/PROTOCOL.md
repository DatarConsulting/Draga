# Frozen protocol: certificate-compatible multiletter pilot

Date: 1 November 2026. Fixed before any full training or test evaluation.

Question: do the gains survive when residual heads have scalar linear outputs
and their effective matrices satisfy counting-measure mean-square stability?
The previous pilot's Jules Verne test is not used. No previous checkpoint is used.

## Corpus and tasks

Fresh relative to this experiment series: French Les malheurs de Sophie,
Project Gutenberg 15058. First 180000 normalized lowercase body characters;
contiguous 140000 / 20000 / 20000 train / validation / test. Exact source,
transformation, split hashes and absence of 64-character overlap are recorded
in data/source.json and data/manifest.json. Vocabulary is training-only + UNK.
No model has evaluated this test before protocol freezing. This is one small
literary corpus, not a broad LLM benchmark or a claim about all prior user work.

Text training: independent reset windows of 64, batch32, 1800 updates. Evaluate
all complete nonoverlapping windows. Select minimum validation BPC every100
steps including0; evaluate test only after selection. Report character BPC
and character perplexity, not token perplexity.

Order: S3 full permutation among6 classes, operations identity, swap01, swap12.
Train batch64, length32, 1500 updates, fresh random sequences, supervise every
prefix. Select validation final-state cross-entropy, seed17001, n512. Test
n1024 at lengths32/64/128 using seeds18000+length. Pairs n512 at32/96, seeds
19001/19002: shared prefix8, ab versus ba, shared suffix. Same counts and
distinct targets, pair success requires BOTH correct. The operation route is
known, unlike the learned text router. Chance independent uniform is1/6 per
sequence and1/36 per pair, not a lower bound for correlated predictions.

## Arms and budgets

Five arms, five seeds101..105, two tasks:50 training jobs. All store64 FP32
recurrent coordinates=256 bytes/sample, excluding weights, temporary training
activations, scratch buffers and framework overhead.

* main_only:64 diagonal linear main states, nonlinear input injection and MLP.
* single:32 main +4 residual heads of8, one transition per head.
* single_param:same recurrence; choose MLP hidden width1..200 with nearest
  total parameter count to multi_cert (tie: smaller width).
* multi_path:32 main +4 heads of8;3 transitions on order,4 on text. Individually
  cap spectral norm at .995, without imposing counting stability.
* multi_cert:identical to multi_path except joint cap: for EACH head, stack
  all transition matrices vertically and cap its spectral norm at .99.

All residual arms use r_t=R_a r_(t-1)+b*u_t; scalar injection per head and
scalar readout c^T r_t. Logits=main_MLP(main_state)+sum_h v_h*(c_h^T r_h).
No LayerNorm/MLP sees residual coordinates. No feedback into main state or
router; text router depends only on current input embedding. Forward hard
argmax routing with straight-through softmax gradient in training. Each mode
starts with the same raw matrix; path and cert share initialization before
normalization. No main or residual pretrained weights are reused.

Embedding32, main readout hidden64 except parameter control, AdamW lr.003,
weight_decay .01, gradient clip1, last20% updates lr.0006. Same examples per
task/seed across arms. Same updates/data, not equal FLOPs. CPU1thread perjob,
three workers. Effective selected FP32 matrices are frozen before evaluation
and exported. Their dyadic coefficients are the exact-real source checked.

## Prespecified endpoints

Compatibility: ALL selected multi_cert heads must pass exact rational LDL
verification of (99/100)I-sum_a R_a^T R_a positive definite, hence stable
counting Hankel. This sufficient constraint is stricter than the general
spectral-radius condition. Failure of this architecture does not refute all
stable multiletter models.

Text success: multi_cert improves mean BPC by >=.02 versus EACH of main_only,
single,single_param, with positive paired improvement on all five seeds.
Order success: mean pair-both-correct at96 improves by >=.10 absolute versus
EACH control, favorable on all five seeds. Joint empirical success requires
both endpoints plus compatibility. Report each endpoint separately even if
joint success fails. Compare multi_cert with multi_path descriptively to
isolate the cost of the joint stability constraint. No post-test tuning,
subgroup selection or favorable-seed selection; report all runs and SD.

## Prespecified secondary compression check

For EVERY multi_cert checkpoint, project each residual head onto its first4
coordinates (8->4, no refitting or test-informed coordinate selection).
Persistent state becomes48 FP32 scalars=192 bytes/sample. This projection
preserves the sufficient stability inequality. Certify the error series by
an exact rational upper bound on its Hankel Hilbert-Schmidt norm, using Stein
equations with exactly verified rational residuals. Transport each scalar
error bound with the SAME routes and injections to a logit-infinity bound,
then TV<=min(1,delta/2). Record numerical replay error and predictive loss;
do not equate a loose upper bound with observed error.

This computes a feasible compression certificate, not the exact optimal AAK
approximation or the real-algebraic optimization algorithm of the manuscript.
The exact certificate concerns real arithmetic with frozen dyadic coefficients;
FP32 execution rounding and free-running token divergence are not certified.

Preserve checkpoints, code, full learning curves, exact proof evidence,
validation/test results, hashes, independent audit and reproduction commands.

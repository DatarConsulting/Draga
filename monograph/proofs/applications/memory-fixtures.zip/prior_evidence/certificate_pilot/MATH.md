# Compatibility and a computable error certificate

This note concerns exact real execution of the stored binary floating-point coefficients, interpreted as dyadic rational numbers. It does not certify floating-point execution roundoff and does not solve an AAK optimal approximation problem.

## Architecture

For each head, use

\[
r_t=R_{a_t}r_{t-1}+b u_t,\qquad r_0=0,\qquad
z_t=z_t^{\mathrm{main}}+\sum_h v_h c_h^\top r_{h,t}.
\]

The main state, route and injection must not depend on the residual state. The scalar readout is essential for the direct application of the single-head lemma. An MLP may read the main state alone; it must not mix all residual coordinates before the additive scalar-head correction. A shared fixed token prefix gives identical routes and injections to the original and reduced heads.

## Exact sufficient stability condition

Choose a rational q in (0,1), for example q=99/100. Check, using exact rational arithmetic, that

\[
qI-\sum_aR_a^\top R_a\succ0.
\]

Exact unpivoted LDL on this symmetric matrix is sufficient if every diagonal pivot is positive. Normalizing the vertical stack of matrices to spectral norm at most 0.99 during training aims at the stronger numerical bound 0.9801 I. The exact post-training check against 0.99 I leaves a margin and makes the saved-coefficient claim independent of the floating-point SVD accuracy.

For every word length n,

\[
\sum_{|w|=n}\|R_wx\|_2^2\le q^n\|x\|_2^2.
\]

Consequently the scalar series f(w)=c^T R_w b is square summable and its word-Hankel matrix is Hilbert--Schmidt:

\[
\|H_f\|_{\mathrm{HS}}^2
=\sum_{n\ge0}(n+1)\sum_{|w|=n}|f(w)|^2
\le\frac{\|c\|_2^2\|b\|_2^2}{(1-q)^2}.
\]

The factor n+1 is the number of decompositions w=uv. In particular, this gives a bounded Hankel operator. Counting stability is stronger than pathwise contraction; this new constraint can reduce empirical memory retention and must not be described as cost-free.

## Projection and the difference realization

For a coordinate projection P with PP^T=I, set

\[
\widehat R_a=PR_aP^\top,\qquad \widehat b=Pb,\qquad \widehat c=Pc.
\]

Then

\[
\sum_a\widehat R_a^\top\widehat R_a
\preceq P\left(\sum_aR_a^\top R_a\right)P^\top\preceq qI.
\]

The difference series e=f-fhat has realization

\[
E_a=\operatorname{diag}(R_a,\widehat R_a),\quad
B=(b,\widehat b)^\top,\quad C=(c,-\widehat c)^\top,
\]

and the same sufficient contraction bound. Coordinate projection is a feasible reduction, not a Hankel-optimal approximation.

## A computable upper bound using exact residuals

Let L(X)=sum_a E_a X E_a^T. Define the exact matrices

\[
G=(I-L)^{-1}(BB^\top),\qquad S=(I-L)^{-1}G.
\]

Then

\[
\|H_e\|_{\mathrm{op}}^2\le\|H_e\|_{\mathrm{HS}}^2=C^\top SC.
\]

A floating-point linear solve may supply symmetric candidate matrices G0 and S0. Interpret their saved binary entries exactly and form exact rational residuals

\[
D_1=BB^\top+L(G_0)-G_0,\qquad
D_2=G_0+L(S_0)-S_0.
\]

For symmetric X, positivity and sum E_a^T E_a <= qI imply
\(\|L(X)\|_*\le q\|X\|_*\), where the star denotes the nuclear norm. Therefore

\[
\|S-S_0\|_*
\le\frac{\|D_1\|_*}{(1-q)^2}+\frac{\|D_2\|_*}{1-q}.
\]

The exact entrywise absolute sum a(D)=sum_ij |D_ij| bounds the nuclear norm, yielding the entirely rational upper bound

\[
U=C^\top S_0C+\|C\|_2^2
\left[\frac{a(D_1)}{(1-q)^2}+\frac{a(D_2)}{1-q}\right].
\]

Thus ||H_e||op <= sqrt(U). The numerical solves do not need to be trusted: only exact positive-definiteness, symmetry, and residual calculations enter the proof. A negative U indicates an implementation or validation error. For reporting, retain U as numerator/denominator and choose an upward rational square-root bound eta by checking eta^2 >= U exactly. A rounded decimal square root alone is not an exact upper bound.

This residual method can be substantially tighter than a generic geometric bound, especially when the two realizations nearly agree. Its accuracy does not imply Hankel optimality.

## Transport to the output

For identical routes and injections and zero initial states, distinct suffix words have distinct lengths. The empty-word column of the Hankel error gives

\[
|c^\top r_t-\widehat c^\top\widehat r_t|
\le\eta\|u_{1:t}\|_2.
\]

For several additive heads,

\[
\|z_t-\widehat z_t\|_\infty
\le\delta_t:=\sum_h\|v_h\|_\infty\eta_h\|u_{h,1:t}\|_2.
\]

If injections are bounded by one, replace each input norm by sqrt(t) for a uniform bound. This bound applies to exact arithmetic on shared input prefixes. The corresponding next-token total variation is at most min(1,delta_t/2), by integrating the softmax Jacobian along the straight logit segment. The next-token negative log-likelihood difference is at most 2 delta_t in natural logarithms, or 2 delta_t / ln(2) in bits. A numerically evaluated certificate should be reported alongside its actual size; a large, vacuous probability bound is still mathematically valid but not practically informative.

The certificate makes no claim that independently sampled autoregressive continuations remain identical. It also does not cover floating-point accumulation, quantization, a state-dependent router, or nonlinear residual readouts without additional arguments.

## A theoretical retention cost of this sufficient constraint

Consider two residual trajectories entering a common suffix, with the same injections and the same independent uniformly sampled symbols from d modes. Their difference obeys Δr_{j+1}=R_{a_{j+1}} Δr_j because the injections cancel. Conditioning on the state difference before each fresh suffix symbol gives

\[
\mathbb E[\|\Delta r_{j+1}\|_2^2\mid\Delta r_j]
=\frac1d\Delta r_j^\top\Bigl(\sum_aR_a^\top R_a\Bigr)\Delta r_j
\le\frac qd\|\Delta r_j\|_2^2.
\]

Hence

\[
\mathbb E\|\Delta r_L\|_2^2
\le (q/d)^L\|\Delta r_0\|_2^2.
\]

In the S3 order experiment the common suffix is uniform on the three operations. For q=0.99 and L=86, the squared-distance factor is (0.99/3)^86 ≈ 3.91×10^-42; the root-mean-square factor is approximately 1.98×10^-21. For the length-32 pairs (suffix L=22), these factors are approximately 2.55×10^-11 and 5.05×10^-6. This is a theoretical consequence of the imposed constraint, independent of the observed test outcomes. It explains why compatibility can come with a substantial retention cost.

These statements concern the residual alone. The separate main memory may still distinguish the prefixes. Finite readout weights may amplify small nonzero real differences; a common-input recurrence cannot reconstruct a distinction once finite-precision states have become exactly equal. The inequality does not establish that the two states do become equal in floating-point, nor that every certificate-compatible architecture fails the task. It concerns this specific sufficient Euclidean constraint, known uniform symbol routing, and this common-suffix comparison. The learned text router is generally nonuniform, so the same q/d calculation cannot be transferred to the text experiment without accounting for its route distribution.
